<?php
include 'db_connection.php';

if(isset($_POST['email'])){
    $email = $_POST['email'];

    $sql = "SELECT * FROM `registration` WHERE email='$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<span style='color:red;'>Email already exists.</span>";
    } else {
        echo "<span style='color:green;'>Email is available.</span>";
    }
}
?>
