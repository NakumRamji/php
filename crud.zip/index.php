<!DOCTYPE html>
<html>
<head>
    <title>Check Username & Email</title>
    <script src="jquery.min.js"></script>
    <script>
        $(document).ready(function(){
            $("#username").keyup(function(){
                var username = $(this).val().trim();
                if(username != ''){
                    $.ajax({
                        url: 'check_username.php',
                        type: 'post',
                        data: {username: username},
                        success: function(response){
                            $('#username_result').html(response);
                        }
                    });
                }else{
                    $('#username_result').html('');
                }
            });

            $("#email").keyup(function(){
                var email = $(this).val().trim();
                if(email != ''){
                    $.ajax({
                        url: 'check_email.php',
                        type: 'post',
                        data: {email: email},
                        success: function(response){
                            $('#email_result').html(response);
                        }
                    });
                }else{
                    $('#email_result').html('');
                }
            });
        });
    </script>
</head>
<body>
    <h2>Check Username & Email</h2>
    <form>
        <label>Username:</label><br>
        <input type="text" id="username" name="username"><br>
        <span id="username_result"></span><br><br>

        <label>Email:</label><br>
        <input type="text" id="email" name="email"><br>
        <span id="email_result"></span><br><br>
    </form>
</body>
</html>
