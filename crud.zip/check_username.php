<?php
include 'db_connection.php';

if(isset($_POST['username'])){
    $username = $_POST['username'];

    $sql = "SELECT * FROM `registration` WHERE username='$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<span style='color:red;'>Username already exists.</span>";
    } else {
        echo "<span style='color:green;'>Username is available.</span>";
    }
}
?>
