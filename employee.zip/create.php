
<?php
	include "config.php";
	
	if(isset($_POST['en'])){
		$en=$_POST['en'];
		$ename=$_POST['ename'];
		$dob=$_POST['dob'];
		$salary=$_POST['salary'];
		$city=$_POST['city'];
		$address=$_POST['address'];
		$email=$_POST['email'];
		$number=$_POST['number'];
		$sql="INSERT INTO `login`( `en`, `ename`, `dob`, `salary`, `city`, `address`, `email`, `contactnumber`,`ative`) VALUES ('$en','$ename','$dob','$salary','$city','$address','$email','$number','Y')";
		$res=mysqli_query($conn,$sql);
		
		if($res == true)
		{
			echo "New record created succssfully.";
		}
		else{
			echo "Error:".$sql."<br>".$conn->error;
		}
		
	}
	
?>
<html>
	<head>
		<title>Empioyee Ragistetion</title>
	</head>
	<body>
		<h2>Signup Form</h2>
		<form action="create.php" method="POST">
			<fieldset>
				<legend>Perosonal Information</legend>
				Empioyee No.:<br>
				<input type="text" name="en"><br>
				Empioyee Name:<br>
				<input type="text" name="ename"><br>
				Date of Birth:<br>
				<input type="date" name="dob"><br>
				Salary:<br>
				<input type="text" name="salary"><br>
				City :<br>
				<select  name="city" >
					<option value="" disabled selected>Select City</option>
					<option>Rajkot</option>
					<option>Jmanagar</option>
					<option>Surat</option>
					<option>Ahmedabad</option>
					<option>Bhavnagar</option>
				</select><br>
				Address :<br>
				<textarea name="address" rows="5" cols="20"></textarea><br>
				Email :<br>
				<input type="email" name="email"><br>
				Contact Number:<br>
				<input type="phone" name="number"><br>
				<input type="submit" value="submit">
			</fieldset>
		</form>
	</body>
</html>

