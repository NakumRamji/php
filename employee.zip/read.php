<?php
	include "config.php";

	$sql = "SELECT * FROM `login` WHERE `ative`='Y' ORDER BY en;";

	$result = $conn->query($sql);
?>
<html>
	<head> <title>Viwe Page</title>
		 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" >
	</head>
	<body>
		<div class="container">
			<table class="table">
			  <thead>
				<tr>
				  <th scope="col">Employrr No.</th>
				  <th scope="col">Employe Nmae</th>
				  <th scope="col">DOB</th>
				  <th scope="col">Salary</th>
				  <th scope="col">City</th>
				  <th scope="col">Address</th>
				  <th scope="col">Email</th>
				  <th scope="col">Phone No.</th>
				  <th scope="col">Action</th>
				</tr>
			  </thead>
			  <tbody>
			  <?php
				if($result->num_rows>0){
					while ($row =$result->fetch_assoc()){
			  ?>
				<tr>
				  <td><?php echo $row['en']; ?></td>
				  <td><?php echo $row['ename']; ?></td>
				  <td><?php echo $row['dob']; ?></td>
				  <td><?php echo $row['salary']; ?></td>
				  <td><?php echo $row['city']; ?></td>
				  <td><?php echo $row['address']; ?></td>
				  <td><?php echo $row['email']; ?></td>
				  <td><?php echo $row['contactnumber']; ?></td>
				  <td><td><a class="btn btn-info" href="update.php?en=<?php echo $row['en']; ?>">Edit</a>&nbsp;<a class="btn btn-danger" href="delete.php?en=<?php echo $row['en']; ?>">Delete</a></td>
				</th>
		<?php		}
			}
					
		?>  
			  </tbody>
			</table>
		</div>
	</body>
</html>

