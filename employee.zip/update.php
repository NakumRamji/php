<?php 

include "config.php";

    if (isset($_POST['update'])) {

        $en=$_POST['en'];
		$ename=$_POST['ename'];
		$dob=$_POST['dob'];
		$salary=$_POST['salary'];
		$city=$_POST['city'];
		$address=$_POST['address'];
		$email=$_POST['email'];
		$number=$_POST['number'];
        $sql="UPDATE `login` SET `ename`='$ename',`dob`='$dob',`salary`='$salary',`city`='$city',`address`='$address',`email`='$email',`contactnumber`='$number' WHERE `en`='$en'";

        $result = $conn->query($sql); 

        if ($result == TRUE) {

            echo "Record updated successfully.";

        }else{

            echo "Error:" . $sql . "<br>" . $conn->error;

        }

    } 

if (isset($_GET['en'])) {

    $user_id = $_GET['en']; 

     $sql = "SELECT *, `contactnumber` AS `number` FROM `login` WHERE `en`='$user_id'";

    $result = $conn->query($sql); 

    if ($result->num_rows > 0) {        

        while ($row = $result->fetch_assoc()) {

            $en=$row['en'];
            $ename=$row['ename'];
            $dob=$row['dob'];
            $salary=$row['salary'];
            $city=$row['city'];
            $address=$row['address'];
            $email=$row['email'];
            $number = $row['number'];
        } 

    ?>

<html>
	<head>
		<title>Empioyee Ragistetion</title>
	</head>
	<body>
		<h2>Udate Form</h2>
		<form action="" method="POST">
			<fieldset>
				<legend>Perosonal Information</legend>
				Empioyee No.:<br>
				<input type="text" name="en" value="<?php echo $en; ?> "><br>
				Empioyee Name:<br>
				<input type="text" name="ename" value="<?php echo $ename; ?>"><br>
				Date of Birth:<br>
				<input type="date" name="dob" value="<?php echo $dob; ?>"><br>
				Salary:<br>
				<input type="text" name="salary" value="<?php echo $salary; ?>"><br>
				City :<br>
                <select name="city">
                    <option value="" disabled>Select City</option>
                    <option value="Rajkot" <?php if($city == 'Rajkot') echo 'selected'; ?>>Rajkot</option>
                    <option value="Jamnagar" <?php if($city == 'Jamnagar') echo 'selected'; ?>>Jamnagar</option>
                    <option value="Surat" <?php if($city == 'Surat') echo 'selected'; ?>>Surat</option>
                    <option value="Ahmedabad" <?php if($city == 'Ahmedabad') echo 'selected'; ?>>Ahmedabad</option>
                    <option value="Bhavnagar" <?php if($city == 'Bhavnagar') echo 'selected'; ?>>Bhavnagar</option>
                </select><br>
                Address :<br>
                <textarea name="address" rows="5" cols="20"><?php echo $address; ?></textarea><br>
				Email :<br>
				<input type="email" name="email" value="<?php echo $email; ?>"><br>
				Contact Number:<br>
				<input type="phone" name="number" value="<?php echo $number; ?>"><br>
				<input type="submit" value="Update" name="update">
			</fieldset>
		</form>
	</body>
</html>
    <?php

    } else{ 

        header('Location: read.php');

    } 

}

?> 