<?php 

include "config.php"; 

if (isset($_GET['en'])) {

    $user_id = $_GET['en'];

    $sql = "UPDATE `login` SET `ative`='N' ";

     $result = $conn->query($sql);

     if ($result == true) {

        echo "Record deleted successfully.";

    }else{

        echo "Error:" . $sql . "<br>" . $conn->error;

    }

} 

?>